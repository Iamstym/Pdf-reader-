package com.example.pdfreader;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.util.LruCache;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Minimal offline PDF reader. Uses the built-in PdfRenderer; renders pages lazily. */
public class MainActivity extends Activity {

    private static final int REQ_OPEN = 1;
    private static final String KEY_URI = "uri";

    private final Object lock = new Object();           // PdfRenderer allows one open page at a time
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final Set<Integer> pending = new HashSet<>();

    private PdfRenderer renderer;
    private ParcelFileDescriptor pfd;
    private ListView list;
    private Button openBtn;
    private LruCache<Integer, Bitmap> cache;
    private Uri current;
    private int pageCount, widthPx, generation;
    private float ratio = 1.414f;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        // Keep page cache small (max ~1/10 of the app's heap, capped at 24 MB).
        long maxHeap = Runtime.getRuntime().maxMemory();
        int cacheBytes = (int) Math.min(24L * 1024 * 1024, maxHeap / 10);
        cache = new LruCache<Integer, Bitmap>(cacheBytes) {
            @Override protected int sizeOf(Integer k, Bitmap b) { return b.getByteCount(); }
        };

        float d = getResources().getDisplayMetrics().density;
        FrameLayout root = new FrameLayout(this);
        list = new ListView(this);
        list.setBackgroundColor(0xFFCCCCCC);
        list.setDivider(new android.graphics.drawable.ColorDrawable(0xFFCCCCCC));
        list.setDividerHeight((int) (8 * d));
        list.setVerticalScrollBarEnabled(true);
        root.addView(list);

        openBtn = new Button(this);
        openBtn.setText("Open a PDF");
        openBtn.setOnClickListener(v -> pickFile());
        root.addView(openBtn, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        setContentView(root);

        Uri uri = null;
        if (state != null && state.getString(KEY_URI) != null) uri = Uri.parse(state.getString(KEY_URI));
        else if (Intent.ACTION_VIEW.equals(getIntent().getAction())) uri = getIntent().getData();
        if (uri != null) open(uri);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (Intent.ACTION_VIEW.equals(intent.getAction()) && intent.getData() != null) open(intent.getData());
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (current != null) out.putString(KEY_URI, current.toString());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 1, 0, "Open").setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == 1) { pickFile(); return true; }
        return super.onOptionsItemSelected(item);
    }

    /** System file picker: no storage permission required. */
    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/pdf");
        startActivityForResult(i, REQ_OPEN);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_OPEN && res == RESULT_OK && data != null && data.getData() != null) open(data.getData());
    }

    private void open(Uri uri) {
        closeRenderer();
        generation++;
        pending.clear();
        cache.evictAll();
        widthPx = getResources().getDisplayMetrics().widthPixels;
        try {
            synchronized (lock) {
                pfd = getContentResolver().openFileDescriptor(uri, "r");
                if (pfd == null) throw new IOException("null fd");
                renderer = new PdfRenderer(pfd);
                pageCount = renderer.getPageCount();
                if (pageCount > 0) {
                    PdfRenderer.Page p = renderer.openPage(0);
                    ratio = (float) p.getHeight() / p.getWidth();
                    p.close();
                }
            }
        } catch (SecurityException e) {
            closeRenderer();
            toast("Password-protected PDFs are not supported");
            return;
        } catch (Exception e) {
            closeRenderer();
            toast("Could not open this file");
            return;
        }
        current = uri;
        openBtn.setVisibility(View.GONE);
        setTitle(displayName(uri) + " (" + pageCount + ")");
        list.setAdapter(new PageAdapter(generation));
    }

    private void closeRenderer() {
        synchronized (lock) {
            try { if (renderer != null) renderer.close(); } catch (Exception ignored) {}
            try { if (pfd != null) pfd.close(); } catch (Exception ignored) {}
            renderer = null; pfd = null; pageCount = 0;
        }
    }

    private String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) return c.getString(idx);
            }
        } catch (Exception ignored) {}
        return "PDF";
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    private Bitmap render(int pos) {
        synchronized (lock) {
            if (renderer == null || pos >= pageCount) return null;
            PdfRenderer.Page page = renderer.openPage(pos);
            try {
                int h = Math.max(1, (int) (widthPx * (float) page.getHeight() / page.getWidth()));
                Bitmap bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888);
                bmp.eraseColor(Color.WHITE);
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                return bmp;
            } finally {
                page.close();
            }
        }
    }

    private class PageAdapter extends BaseAdapter {
        private final int gen;
        PageAdapter(int gen) { this.gen = gen; }

        @Override public int getCount() { return pageCount; }
        @Override public Object getItem(int p) { return null; }
        @Override public long getItemId(int p) { return p; }

        @Override
        public View getView(int pos, View convert, ViewGroup parent) {
            ImageView iv = (ImageView) convert;
            if (iv == null) {
                iv = new ImageView(MainActivity.this);
                iv.setAdjustViewBounds(true);
                iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                iv.setBackgroundColor(Color.WHITE);
                iv.setLayoutParams(new AbsListView.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            iv.setTag(pos);
            Bitmap b = cache.get(pos);
            if (b != null) {
                iv.setMinimumHeight(0);
                iv.setImageBitmap(b);
            } else {
                iv.setImageDrawable(null);
                iv.setMinimumHeight((int) (widthPx * ratio));
                load(pos, iv, gen);
            }
            return iv;
        }

        private void load(final int pos, final ImageView iv, final int g) {
            if (!pending.add(pos)) return;
            exec.execute(() -> {
                Bitmap b = null;
                // Skip work if user already scrolled past this page.
                if (g == generation && iv.getTag() instanceof Integer && (Integer) iv.getTag() == pos) {
                    try { b = render(pos); } catch (Exception ignored) {}
                }
                final Bitmap result = b;
                runOnUiThread(() -> {
                    pending.remove(pos);
                    if (g != generation || result == null) {
                        // Retry if it's still on screen and wasn't rendered.
                        if (g == generation && iv.getTag() instanceof Integer && (Integer) iv.getTag() == pos
                                && result == null && renderer != null) notifyDataSetChanged();
                        return;
                    }
                    cache.put(pos, result);
                    if (iv.getTag() instanceof Integer && (Integer) iv.getTag() == pos) {
                        iv.setMinimumHeight(0);
                        iv.setImageBitmap(result);
                    }
                });
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        generation++;
        exec.shutdownNow();
        closeRenderer();
        cache.evictAll();
    }
}
