# Simple PDF (Android)

Offline PDF reader. Zero permissions, zero dependencies, ~50-100 KB APK.

## Build the APK
1. Install Android Studio (free), then File > Open > select this folder. Let Gradle sync.
2. Build > Build Bundle(s) / APK(s) > Build APK(s)  (debug), or
   Build > Generate Signed App Bundle / APK for your own keystore.
   Or from a terminal: `gradle assembleRelease`
   Output: app/build/outputs/apk/release/app-release.apk

## Share / install
Send the .apk (WhatsApp, Telegram, Drive, USB). On the phone, tap it and allow
"Install unknown apps" for that source when asked.

## Notes
- Android 5.0+ (API 21+).
- Open files via the in-app Open button, or from any file manager/WhatsApp/email "Open with".
- Password-protected PDFs are not supported by Android's built-in renderer.
